#include "serialreceiver.h"

using namespace ATeam;

SerialReceiver::SerialReceiver(uint32_t baudrate) :
  _baudrate(baudrate)
{

}

bool SerialReceiver::receiveMessage(uint32_t *data, size_t size)
{
  size_t readBytes = 0; // Couter of nr of data received
  uint8_t bytes = 0; // Couter of nr of bytes received
  uint32_t singleData = 0; // Storage for the first three bytes

  const uint32_t stopNumber = 112; // Start identifier for the fourth received byte
  const uint32_t startNumber = 111; // Stop identifier for the fourth received byte

  bool stop = false;
  bool start = false;

  while (!stop) {
    // Read the byte
    if (Serial.available())
    {
      uint8_t inByte = (uint8_t)Serial.read();
      //Serial.println(inByte);

      if (bytes <= 2 && start)
      {
        // Add to uint32 value
        uint32_t translated = (uint32_t)inByte << (8 * bytes);
        singleData |= translated;
      }

      // For the last byte, check for identifier
      if (bytes == 3)
      {
        // If it was a stop identifier, stop with reading
        if (inByte == stopNumber)
        {
          digitalWrite(13, LOW);
          stop = true;
          start = false;
          continue;
        }

        // If it was not a stop identifier, add the new data to the array
        else if (start)
        {
          *data = singleData;
          readBytes++;

          // Out of buffer check
          if (readBytes < size)
          {
            data++;
            singleData = 0;
            bytes = 0;
            continue;
          }
          // Stop if out of buffer
          else
          {
            stop = true;
            start = false;
            continue;
          }
        }

        // If it was a start identifier, start reading the new data
        else if (inByte == startNumber)
        {
          digitalWrite(13, HIGH);
          start = true;
          bytes = 0;
          continue;
        }
      }
      
      bytes++;
      // Delay for receiving the next char
      delayMicroseconds(20);
    }
  }
  return readBytes != 0;
}

void SerialReceiver::init()
{
  Serial.begin(_baudrate);
}
