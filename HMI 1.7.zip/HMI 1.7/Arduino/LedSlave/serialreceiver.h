#ifndef SERIALRECEIVER_H
#define SERIALRECEIVER_H

#include <Arduino.h>
namespace ATeam {

class SerialReceiver
{
  public:
    SerialReceiver(uint32_t baudrate);
    uint32_t getBaudrate() const { return _baudrate; }
    bool receiveMessage(uint32_t *data, size_t size);
    void init();
  private:
    //const int _baudrate;
    const uint32_t _baudrate;
};

} // namespace ATeam

#endif // SERIALRECEIVER_H
